//! # KpThink
//!
//! A collection of utilities to enable KpThink happened and efficient.


# KpThink

Think-Tank to promote "<b>Core Values of Honesty &amp; Care</b>"
